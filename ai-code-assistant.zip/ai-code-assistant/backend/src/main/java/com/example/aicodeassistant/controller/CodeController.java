package com.yourcompany.codeassistant.controller;

import com.yourcompany.codeassistant.model.BugReport;
import com.yourcompany.codeassistant.model.CodeSnippet;
import com.yourcompany.codeassistant.service.CodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CodeController {

    @Autowired
    private CodeService codeService;

    // Save code snippet
    @PostMapping("/codesnippets")
    public CodeSnippet addCodeSnippet(@RequestBody CodeSnippet snippet) {
        return codeService.saveCodeSnippet(snippet);
    }

    // Get all code snippets
    @GetMapping("/codesnippets")
    public List<CodeSnippet> getAllCodeSnippets() {
        return codeService.getAllCodeSnippets();
    }

    // Save bug report
    @PostMapping("/bugreports")
    public BugReport addBugReport(@RequestBody BugReport bugReport) {
        return codeService.saveBugReport(bugReport);
    }

    // Get all bug reports
    @GetMapping("/bugreports")
    public List<BugReport> getAllBugReports() {
        return codeService.getAllBugReports();
    }
}
