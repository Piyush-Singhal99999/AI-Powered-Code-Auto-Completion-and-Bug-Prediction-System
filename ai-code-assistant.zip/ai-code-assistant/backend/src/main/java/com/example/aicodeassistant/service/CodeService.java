package com.yourcompany.codeassistant.service;

import com.yourcompany.codeassistant.model.BugReport;
import com.yourcompany.codeassistant.model.CodeSnippet;
import com.yourcompany.codeassistant.repository.BugReportRepository;
import com.yourcompany.codeassistant.repository.CodeSnippetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CodeService {

    @Autowired
    private CodeSnippetRepository codeSnippetRepository;

    @Autowired
    private BugReportRepository bugReportRepository;

    // Save CodeSnippet
    public CodeSnippet saveCodeSnippet(CodeSnippet snippet) {
        return codeSnippetRepository.save(snippet);
    }

    // Get all CodeSnippets
    public List<CodeSnippet> getAllCodeSnippets() {
        return codeSnippetRepository.findAll();
    }

    // Save BugReport
    public BugReport saveBugReport(BugReport bugReport) {
        return bugReportRepository.save(bugReport);
    }

    // Get all BugReports
    public List<BugReport> getAllBugReports() {
        return bugReportRepository.findAll();
    }
}
