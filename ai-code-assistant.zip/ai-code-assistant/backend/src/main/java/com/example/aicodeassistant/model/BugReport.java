package com.yourcompany.codeassistant.model;

import jakarta.persistence.*;

@Entity
@Table(name = "bug_reports")
public class BugReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String bugDescription;

    private String status;

    // Constructors, getters, setters
    public BugReport() {}

    public BugReport(String bugDescription, String status) {
        this.bugDescription = bugDescription;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getBugDescription() { return bugDescription; }
    public void setBugDescription(String bugDescription) { this.bugDescription = bugDescription; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
